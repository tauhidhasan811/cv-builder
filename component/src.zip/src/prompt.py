import os

from component.src.data import formatted_data

def augmented_prompt(query, data):

    query_lower = query.lower()
    